var wms_layers = [];


        var lyr_OSMStandard_0 = new ol.layer.Tile({
            'title': 'OSM Standard',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' &middot; <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_wydz_pol_1 = new ol.format.GeoJSON();
var features_wydz_pol_1 = format_wydz_pol_1.readFeatures(json_wydz_pol_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_wydz_pol_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_wydz_pol_1.addFeatures(features_wydz_pol_1);
var lyr_wydz_pol_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_wydz_pol_1, 
                style: style_wydz_pol_1,
                interactive: true,
                title: '<img src="styles/legend/wydz_pol_1.png" /> wydz_pol'
            });
var format_Moratoriumrezultat_zapytania_sql_2 = new ol.format.GeoJSON();
var features_Moratoriumrezultat_zapytania_sql_2 = format_Moratoriumrezultat_zapytania_sql_2.readFeatures(json_Moratoriumrezultat_zapytania_sql_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Moratoriumrezultat_zapytania_sql_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Moratoriumrezultat_zapytania_sql_2.addFeatures(features_Moratoriumrezultat_zapytania_sql_2);
var lyr_Moratoriumrezultat_zapytania_sql_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Moratoriumrezultat_zapytania_sql_2, 
                style: style_Moratoriumrezultat_zapytania_sql_2,
                interactive: true,
                title: '<img src="styles/legend/Moratoriumrezultat_zapytania_sql_2.png" /> Moratorium — rezultat_zapytania_sql'
            });

lyr_OSMStandard_0.setVisible(true);lyr_wydz_pol_1.setVisible(true);lyr_Moratoriumrezultat_zapytania_sql_2.setVisible(true);
var layersList = [lyr_OSMStandard_0,lyr_wydz_pol_1,lyr_Moratoriumrezultat_zapytania_sql_2];
lyr_wydz_pol_1.set('fieldAliases', {'id_adres': 'id_adres', 'adr_les': 'adr_les', 'area_type': 'area_type', 'sub_area': 'sub_area', 'poddz': 'poddz', 'map_TSL': 'map_TSL', 'map_SPEC': 'map_SPEC', 'rys': 'rys', 'label': 'label', 'powOb': 'powOb', 'obwOb': 'obwOb', });
lyr_Moratoriumrezultat_zapytania_sql_2.set('fieldAliases', {'fid': 'fid', 'a_i_num': 'a_i_num', 'adr_for': 'adr_for', 'area_type': 'area_type', 'site_type': 'site_type', 'silvicult': 'silvicult', 'forest_fun': 'forest_fun', 'stand_stru': 'stand_stru', 'rotat_age': 'rotat_age', 'sub_area': 'sub_area', 'prot_categ': 'prot_categ', 'species_cd': 'species_cd', 'part_cd': 'part_cd', 'spec_age': 'spec_age', 'a_year': 'a_year', 'site_int_num': 'site_int_num', 'arodes_int_num': 'arodes_int_num', 'prot_site_cd': 'prot_site_cd', 'prot_site_state': 'prot_site_state', 'a_year:1': 'a_year:1', });
lyr_wydz_pol_1.set('fieldImages', {'id_adres': 'TextEdit', 'adr_les': 'TextEdit', 'area_type': 'TextEdit', 'sub_area': 'TextEdit', 'poddz': 'TextEdit', 'map_TSL': 'TextEdit', 'map_SPEC': 'TextEdit', 'rys': 'Range', 'label': 'TextEdit', 'powOb': 'TextEdit', 'obwOb': 'TextEdit', });
lyr_Moratoriumrezultat_zapytania_sql_2.set('fieldImages', {'fid': 'TextEdit', 'a_i_num': 'TextEdit', 'adr_for': 'TextEdit', 'area_type': 'TextEdit', 'site_type': 'TextEdit', 'silvicult': 'TextEdit', 'forest_fun': 'TextEdit', 'stand_stru': 'TextEdit', 'rotat_age': 'TextEdit', 'sub_area': 'TextEdit', 'prot_categ': 'TextEdit', 'species_cd': 'TextEdit', 'part_cd': 'TextEdit', 'spec_age': 'TextEdit', 'a_year': 'TextEdit', 'site_int_num': 'TextEdit', 'arodes_int_num': 'TextEdit', 'prot_site_cd': 'TextEdit', 'prot_site_state': 'TextEdit', 'a_year:1': 'TextEdit', });
lyr_wydz_pol_1.set('fieldLabels', {'id_adres': 'no label', 'adr_les': 'no label', 'area_type': 'no label', 'sub_area': 'no label', 'poddz': 'no label', 'map_TSL': 'no label', 'map_SPEC': 'no label', 'rys': 'no label', 'label': 'no label', 'powOb': 'no label', 'obwOb': 'no label', });
lyr_Moratoriumrezultat_zapytania_sql_2.set('fieldLabels', {'fid': 'no label', 'a_i_num': 'no label', 'adr_for': 'no label', 'area_type': 'no label', 'site_type': 'no label', 'silvicult': 'no label', 'forest_fun': 'no label', 'stand_stru': 'no label', 'rotat_age': 'no label', 'sub_area': 'no label', 'prot_categ': 'no label', 'species_cd': 'no label', 'part_cd': 'no label', 'spec_age': 'no label', 'a_year': 'no label', 'site_int_num': 'no label', 'arodes_int_num': 'no label', 'prot_site_cd': 'no label', 'prot_site_state': 'no label', 'a_year:1': 'no label', });
lyr_Moratoriumrezultat_zapytania_sql_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});